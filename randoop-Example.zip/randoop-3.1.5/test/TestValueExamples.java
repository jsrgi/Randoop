
  import randoop.*;

  public class TestValueExamples {

    @TestValue
    public static int i = 0;

    @TestValue
    public static boolean b = false;

    @TestValue
    public static byte by = 3;

    @TestValue
    public static char c = 'c';

    @TestValue
    public static long l = 3L;

    @TestValue
    public static float f = (float) 1.3;

    @TestValue
    public static double d = 1.4;

    @TestValue
    public static String s1 = null;

    @TestValue
    public static String s2 = "hi";

    @TestValue
    public static int[] a1 = new int[] { 1, 2, 3 };

  }