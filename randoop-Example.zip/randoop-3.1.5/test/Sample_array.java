import java.io.*;
import java.util.*;

public class Sample_array{
public static void main(String args[]){
	Scanner Scan=new Scanner(System.in);
	System.out.println("INPUT :");
	int size = Scan.nextInt();
//System.out.println("hello javatpoint");
System.out.println("USER INPUT " + size);

int[] arr = new int[size];

	for (int i=0;i<size;i++)
	{
		arr[i] = Scan.nextInt();
	}

	for (int i=0;i<size;i++)
	{
		System.out.println("array value " + (i+1) +" : " + arr[i]);
	}


int v = size/2;
//~ System.out.println(v);
int result1 = 0;
int result2 = 0;
int result3 = 0;

int val = size%2;
//~ System.out.println(val);

	if(val<1)
	{   
		System.out.println("The given array value is EVEN");
		
				for (int i=0;i<v;i++)
			{
			    result1 += arr[i];				
			}
			System.out.println("First half value : "+ result1);
			
				for (int i=v;i<size;i++)
			{
				result2 += arr[i];				
			}
			System.out.println("Second half value : "+ result2);
			
			int result = result1 + result2;
			System.out.println("Final value : "+ result);
			
		 
	}
	else {
		
		System.out.println("The given array value is ODD");
		
				for (int i=0;i<v;i++)
			{
			    result1 += arr[i];				
			}
			System.out.println("First half value : "+ result1);
			
				for (int i=v+1;i<size;i++)
			{
				result2 += arr[i];				
			}
			System.out.println("Second half value : "+ result2);
			
			for (int i=v;i<v+1;i++)
			{
				result3 += arr[i];				
			}
			System.out.println("Middle value : "+ result3);
			
			
			
			int result = result1 + result2 + result3;
			System.out.println("Final value : "+ result);
	}

}}
