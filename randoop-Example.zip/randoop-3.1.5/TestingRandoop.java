public class TestingRandoop
{
public int sum(int a,int b)
{
return a+b;
}
public int sum(int a,int b,int c)
{
return a+b+c;
}
}