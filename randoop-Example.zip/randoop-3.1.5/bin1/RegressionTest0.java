import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test01");
        java.util.ListIterator<java.lang.Comparable<java.lang.String>> listiterator_comparable_str0 = java.util.Collections.emptyListIterator();
        org.junit.Assert.assertNotNull(listiterator_comparable_str0);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test02");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.ListIterator<java.lang.Comparable<java.lang.String>> listiterator_comparable_str4 = java.util.Collections.emptyListIterator();
        java.lang.Object[] obj_array33 = new java.lang.Object[] { "hi!", (short) 10, listiterator_comparable_str4, 1L, "hi!", (byte) 0, (short) 100, (byte) 100, 100.0d, (short) 0, "hi!", "", (short) 1, 1L, (byte) 0, (short) 1, 100.0f, 10.0f, (byte) 10, (byte) 0, (-1.0d), 1.0d, (byte) 100, 100, 1L, (byte) 0, 100.0f, (-1.0d), 1.0d, (-1), false };
        java.util.ArrayList<java.lang.Object> arraylist_obj34 = new java.util.ArrayList<java.lang.Object>();
        boolean b35 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj34, obj_array33);
        try {
            boolean b36 = treeset_obj1.addAll((java.util.Collection<java.lang.Object>) arraylist_obj34);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(listiterator_comparable_str4);
        org.junit.Assert.assertNotNull(obj_array33);
        org.junit.Assert.assertTrue(b35 == true);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test03");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        try {
            boolean b5 = treeset_obj1.remove((java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test04");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        java.util.ListIterator<java.lang.Comparable<java.lang.String>> listiterator_comparable_str4 = java.util.Collections.emptyListIterator();
        java.util.ListIterator<java.lang.Comparable<java.lang.String>> listiterator_comparable_str5 = java.util.Collections.emptyListIterator();
        java.util.ListIterator[] listIterator_array7 = new java.util.ListIterator[2];
        @SuppressWarnings("unchecked") java.util.ListIterator<java.lang.Comparable<java.lang.String>>[] listiterator_comparable_str_array8 = (java.util.ListIterator<java.lang.Comparable<java.lang.String>>[]) listIterator_array7;
        listiterator_comparable_str_array8[0] = listiterator_comparable_str4;
        listiterator_comparable_str_array8[1] = listiterator_comparable_str5;
        try {
            java.util.ListIterator<java.lang.Comparable<java.lang.String>>[] listiterator_comparable_str_array13 = treeset_obj1.toArray(listiterator_comparable_str_array8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayStoreException");
        } catch (java.lang.ArrayStoreException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
        org.junit.Assert.assertNotNull(listiterator_comparable_str4);
        org.junit.Assert.assertNotNull(listiterator_comparable_str5);
        org.junit.Assert.assertNotNull(listIterator_array7);
        org.junit.Assert.assertNotNull(listiterator_comparable_str_array8);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test05");
        java.util.Set<java.lang.Comparable<java.lang.String>> set_comparable_str1 = java.util.Collections.singleton((java.lang.Comparable<java.lang.String>) "hi!");
        org.junit.Assert.assertNotNull(set_comparable_str1);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test06");
        java.util.SortedSet<java.lang.Object> sortedset_obj0 = null;
        try {
            java.util.SortedSet<java.lang.Object> sortedset_obj1 = java.util.Collections.synchronizedSortedSet(sortedset_obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test07");
        java.util.NavigableSet<java.lang.Object> navigableset_obj0 = null;
        java.lang.Class<java.lang.Object> cls1 = null;
        try {
            java.util.NavigableSet<java.lang.Object> navigableset_obj2 = java.util.Collections.checkedNavigableSet(navigableset_obj0, cls1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test08");
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Object[] obj_array5 = new java.lang.Object[] { (byte) 1, (short) 100, (-1.0f), (short) 100, obj4 };
        java.util.ArrayList<java.lang.Object> arraylist_obj6 = new java.util.ArrayList<java.lang.Object>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj6, obj_array5);
        java.util.Collections.reverse((java.util.List<java.lang.Object>) arraylist_obj6);
        java.lang.Object obj9 = new java.lang.Object();
        boolean b11 = java.util.Collections.replaceAll((java.util.List<java.lang.Object>) arraylist_obj6, obj9, (java.lang.Object) 1L);
        java.util.List<java.lang.Object> list_obj12 = java.util.Collections.synchronizedList((java.util.List<java.lang.Object>) arraylist_obj6);
        java.lang.Class<java.lang.Object> cls13 = null;
        try {
            java.util.List<java.lang.Object> list_obj14 = java.util.Collections.checkedList(list_obj12, cls13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj_array5);
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(list_obj12);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test09");
        java.util.Collection<java.lang.Object> collection_obj0 = null;
        java.util.Comparator<java.lang.Object> comparator_obj1 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj2 = new java.util.TreeSet<java.lang.Object>(comparator_obj1);
        java.lang.Object[] obj_array4 = new java.lang.Object[] { treeset_obj2, 100L };
        try {
            boolean b5 = java.util.Collections.addAll(collection_obj0, obj_array4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj1);
        org.junit.Assert.assertNotNull(obj_array4);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test10");
        java.util.SortedSet<java.lang.Object> sortedset_obj0 = null;
        try {
            java.util.SortedSet<java.lang.Object> sortedset_obj1 = java.util.Collections.unmodifiableSortedSet(sortedset_obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test11");
        java.util.Map<java.lang.Cloneable, java.util.stream.Stream<java.lang.Object>> map_cloneable_stream_obj0 = java.util.Collections.emptyMap();
        org.junit.Assert.assertNotNull(map_cloneable_stream_obj0);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test12");
        java.util.ListIterator<java.util.Set<java.lang.Object>> listiterator_set_obj0 = java.util.Collections.emptyListIterator();
        org.junit.Assert.assertNotNull(listiterator_set_obj0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test13");
        java.util.Set<java.util.ArrayList<java.lang.Object>> set_arraylist_obj0 = java.util.Collections.emptySet();
        org.junit.Assert.assertNotNull(set_arraylist_obj0);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test14");
        java.util.SortedMap<java.util.RandomAccess, java.lang.String> sortedmap_randomAccess_str0 = java.util.Collections.emptySortedMap();
        java.util.Map<java.util.RandomAccess, java.lang.String> map_randomAccess_str1 = java.util.Collections.synchronizedMap((java.util.Map<java.util.RandomAccess, java.lang.String>) sortedmap_randomAccess_str0);
        org.junit.Assert.assertNotNull(sortedmap_randomAccess_str0);
        org.junit.Assert.assertNotNull(map_randomAccess_str1);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test15");
        java.util.NavigableSet<java.lang.Iterable<java.lang.Object>> navigableset_iterable_obj0 = java.util.Collections.emptyNavigableSet();
        org.junit.Assert.assertNotNull(navigableset_iterable_obj0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test16");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        java.lang.Class<java.lang.Object> cls4 = null;
        try {
            java.util.NavigableSet<java.lang.Object> navigableset_obj5 = java.util.Collections.checkedNavigableSet((java.util.NavigableSet<java.lang.Object>) treeset_obj1, cls4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test17");
        java.util.NavigableMap<java.util.stream.BaseStream<java.lang.Object, java.util.stream.Stream<java.lang.Object>>, java.util.AbstractList<java.lang.Object>> navigablemap_basestream_obj_stream_obj_abstractlist_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_basestream_obj_stream_obj_abstractlist_obj0);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test18");
        java.util.List<java.io.Serializable> list_serializable0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_serializable0);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test19");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.stream.Stream<java.lang.Object> stream_obj2 = treeset_obj1.stream();
        java.util.Comparator<java.lang.Object> comparator_obj3 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj4 = new java.util.TreeSet<java.lang.Object>(comparator_obj3);
        boolean b6 = treeset_obj4.equals((java.lang.Object) (short) 0);
        try {
            java.util.NavigableSet<java.lang.Object> navigableset_obj8 = treeset_obj1.headSet((java.lang.Object) treeset_obj4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(stream_obj2);
        org.junit.Assert.assertNotNull(comparator_obj3);
        org.junit.Assert.assertTrue(b6 == false);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test20");
        java.util.List<java.lang.CharSequence> list_charSequence2 = java.util.Collections.nCopies(0, (java.lang.CharSequence) "");
        org.junit.Assert.assertNotNull(list_charSequence2);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test21");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.Comparator<java.lang.Object> comparator_obj2 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj3 = new java.util.TreeSet<java.lang.Object>(comparator_obj2);
        boolean b5 = treeset_obj3.equals((java.lang.Object) (short) 0);
        try {
            java.util.NavigableSet<java.lang.Object> navigableset_obj7 = treeset_obj1.headSet((java.lang.Object) treeset_obj3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(comparator_obj2);
        org.junit.Assert.assertTrue(b5 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test22");
        java.util.Map map0 = java.util.Collections.EMPTY_MAP;
        org.junit.Assert.assertNotNull(map0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test23");
        java.util.SortedSet<java.util.NavigableSet<java.lang.Object>> sortedset_navigableset_obj0 = java.util.Collections.emptySortedSet();
        org.junit.Assert.assertNotNull(sortedset_navigableset_obj0);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test24");
        java.util.SortedMap<java.io.Serializable, java.lang.Comparable<java.lang.String>> sortedmap_serializable_comparable_str0 = java.util.Collections.emptySortedMap();
        org.junit.Assert.assertNotNull(sortedmap_serializable_comparable_str0);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test25");
        java.util.NavigableMap<java.util.AbstractSet<java.lang.Object>, java.util.Enumeration<java.lang.Object>> navigablemap_abstractset_obj_enumeration_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_abstractset_obj_enumeration_obj0);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test26");
        java.util.Set<java.util.SortedSet<java.lang.Object>> set_sortedset_obj0 = java.util.Collections.emptySet();
        org.junit.Assert.assertNotNull(set_sortedset_obj0);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test27");
        java.util.List<java.lang.Object> list_obj0 = null;
        java.lang.Object obj5 = new java.lang.Object();
        java.lang.Object[] obj_array6 = new java.lang.Object[] { (byte) 1, (short) 100, (-1.0f), (short) 100, obj5 };
        java.util.ArrayList<java.lang.Object> arraylist_obj7 = new java.util.ArrayList<java.lang.Object>();
        boolean b8 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj7, obj_array6);
        java.util.Collections.reverse((java.util.List<java.lang.Object>) arraylist_obj7);
        java.lang.Object obj10 = new java.lang.Object();
        boolean b12 = java.util.Collections.replaceAll((java.util.List<java.lang.Object>) arraylist_obj7, obj10, (java.lang.Object) 1L);
        java.util.List<java.lang.Object> list_obj13 = java.util.Collections.synchronizedList((java.util.List<java.lang.Object>) arraylist_obj7);
        try {
            int i14 = java.util.Collections.indexOfSubList(list_obj0, list_obj13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj_array6);
        org.junit.Assert.assertTrue(b8 == true);
        org.junit.Assert.assertTrue(b12 == false);
        org.junit.Assert.assertNotNull(list_obj13);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test28");
        java.util.NavigableMap<java.lang.Cloneable, java.util.AbstractCollection<java.lang.Object>> navigablemap_cloneable_abstractcollection_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_cloneable_abstractcollection_obj0);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test29");
        java.util.NavigableMap<java.util.Set<java.lang.Object>, java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>>> navigablemap_set_obj_navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_set_obj_navigablemap_listiterator_comparable_str_navigableset_obj0);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test30");
        java.util.Map<java.util.Comparator<java.lang.Object>, java.util.AbstractList<java.lang.Object>> map_comparator_obj_abstractlist_obj0 = java.util.Collections.emptyMap();
        org.junit.Assert.assertNotNull(map_comparator_obj_abstractlist_obj0);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test31");
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyNavigableMap();
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj1 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj2 = java.util.Collections.unmodifiableNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj1);
        java.lang.Class<java.util.ListIterator<java.lang.Comparable<java.lang.String>>> cls3 = null;
        java.lang.Class<java.util.NavigableSet<java.lang.Object>> cls4 = null;
        try {
            java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj5 = java.util.Collections.checkedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj2, cls3, cls4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj1);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj2);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test32");
        java.util.NavigableSet<java.lang.Object> navigableset_obj0 = null;
        try {
            java.util.NavigableSet<java.lang.Object> navigableset_obj1 = java.util.Collections.unmodifiableNavigableSet(navigableset_obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test33");
        java.util.SortedMap<java.util.RandomAccess, java.lang.String> sortedmap_randomAccess_str0 = java.util.Collections.emptySortedMap();
        java.lang.Class<java.util.RandomAccess> cls1 = null;
        java.lang.Class<java.lang.String> cls2 = null;
        try {
            java.util.Map<java.util.RandomAccess, java.lang.String> map_randomAccess_str3 = java.util.Collections.checkedMap((java.util.Map<java.util.RandomAccess, java.lang.String>) sortedmap_randomAccess_str0, cls1, cls2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(sortedmap_randomAccess_str0);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test34");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        java.lang.Class<java.lang.Object> cls4 = null;
        try {
            java.util.Collection<java.lang.Object> collection_obj5 = java.util.Collections.checkedCollection((java.util.Collection<java.lang.Object>) treeset_obj1, cls4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test35");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.SortedMap<java.util.RandomAccess, java.lang.String> sortedmap_randomAccess_str1 = java.util.Collections.emptySortedMap();
        java.util.Map<java.util.Comparator<java.lang.Object>, java.util.SortedMap<java.util.RandomAccess, java.lang.String>> map_comparator_obj_sortedmap_randomAccess_str2 = java.util.Collections.singletonMap(comparator_obj0, sortedmap_randomAccess_str1);
        java.util.Map<java.util.RandomAccess, java.lang.String> map_randomAccess_str3 = java.util.Collections.synchronizedMap((java.util.Map<java.util.RandomAccess, java.lang.String>) sortedmap_randomAccess_str1);
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(sortedmap_randomAccess_str1);
        org.junit.Assert.assertNotNull(map_comparator_obj_sortedmap_randomAccess_str2);
        org.junit.Assert.assertNotNull(map_randomAccess_str3);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test36");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.equals((java.lang.Object) (short) 0);
        java.lang.Object obj4 = treeset_obj1.pollFirst();
        try {
            java.lang.Object obj5 = treeset_obj1.last();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test37");
        java.util.Set<java.util.Collection<java.lang.Object>> set_collection_obj0 = java.util.Collections.emptySet();
        org.junit.Assert.assertNotNull(set_collection_obj0);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test38");
        java.util.NavigableMap<java.lang.Object[], java.lang.AutoCloseable> navigablemap_obj_array_autoCloseable0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_obj_array_autoCloseable0);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test39");
        java.util.AbstractList<java.lang.Object> abstractlist_obj0 = null;
        java.util.ArrayList<java.lang.Object> arraylist_obj1 = null;
        java.util.Map<java.util.AbstractList<java.lang.Object>, java.util.ArrayList<java.lang.Object>> map_abstractlist_obj_arraylist_obj2 = java.util.Collections.singletonMap(abstractlist_obj0, arraylist_obj1);
        org.junit.Assert.assertNotNull(map_abstractlist_obj_arraylist_obj2);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test40");
        java.util.Iterator<java.util.ArrayList<java.lang.Object>> iterator_arraylist_obj0 = java.util.Collections.emptyIterator();
        org.junit.Assert.assertNotNull(iterator_arraylist_obj0);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test41");
        java.util.List<java.util.RandomAccess> list_randomAccess0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_randomAccess0);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test42");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        java.lang.Class<java.lang.Object> cls4 = null;
        try {
            java.util.Set<java.lang.Object> set_obj5 = java.util.Collections.checkedSet((java.util.Set<java.lang.Object>) treeset_obj1, cls4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test43");
        java.util.Enumeration<java.util.ArrayList<java.lang.Object>> enumeration_arraylist_obj0 = java.util.Collections.emptyEnumeration();
        org.junit.Assert.assertNotNull(enumeration_arraylist_obj0);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test44");
        java.util.NavigableMap<java.util.Map<java.util.RandomAccess, java.lang.String>, java.util.SortedSet<java.lang.Object>> navigablemap_map_randomAccess_str_sortedset_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_map_randomAccess_str_sortedset_obj0);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test45");
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Object[] obj_array5 = new java.lang.Object[] { (byte) 1, (short) 100, (-1.0f), (short) 100, obj4 };
        java.util.ArrayList<java.lang.Object> arraylist_obj6 = new java.util.ArrayList<java.lang.Object>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj6, obj_array5);
        java.util.Collections.reverse((java.util.List<java.lang.Object>) arraylist_obj6);
        java.lang.Object obj9 = new java.lang.Object();
        boolean b11 = java.util.Collections.replaceAll((java.util.List<java.lang.Object>) arraylist_obj6, obj9, (java.lang.Object) 1L);
        java.util.List<java.lang.Object> list_obj12 = java.util.Collections.synchronizedList((java.util.List<java.lang.Object>) arraylist_obj6);
        java.lang.Object obj17 = new java.lang.Object();
        java.lang.Object[] obj_array18 = new java.lang.Object[] { (byte) 1, (short) 100, (-1.0f), (short) 100, obj17 };
        java.util.ArrayList<java.lang.Object> arraylist_obj19 = new java.util.ArrayList<java.lang.Object>();
        boolean b20 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj19, obj_array18);
        java.util.Collections.reverse((java.util.List<java.lang.Object>) arraylist_obj19);
        java.lang.Object obj22 = new java.lang.Object();
        boolean b24 = java.util.Collections.replaceAll((java.util.List<java.lang.Object>) arraylist_obj19, obj22, (java.lang.Object) 1L);
        java.util.Comparator<java.lang.Object> comparator_obj25 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj26 = new java.util.TreeSet<java.lang.Object>(comparator_obj25);
        try {
            int i27 = java.util.Collections.binarySearch((java.util.List<java.lang.Object>) arraylist_obj6, arraylist_obj19, comparator_obj25);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj_array5);
        org.junit.Assert.assertTrue(b7 == true);
        org.junit.Assert.assertTrue(b11 == false);
        org.junit.Assert.assertNotNull(list_obj12);
        org.junit.Assert.assertNotNull(obj_array18);
        org.junit.Assert.assertTrue(b20 == true);
        org.junit.Assert.assertTrue(b24 == false);
        org.junit.Assert.assertNotNull(comparator_obj25);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test46");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        try {
            java.lang.Object obj2 = treeset_obj1.first();
            org.junit.Assert.fail("Expected exception of type java.util.NoSuchElementException");
        } catch (java.util.NoSuchElementException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test47");
        java.util.ListIterator<java.lang.Object[]> listiterator_obj_array0 = java.util.Collections.emptyListIterator();
        org.junit.Assert.assertNotNull(listiterator_obj_array0);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test48");
        java.util.Collection<java.lang.Object> collection_obj0 = null;
        java.lang.CharSequence[] charSequence_array3 = new java.lang.CharSequence[] { "[1]", "hi!" };
        try {
            boolean b4 = java.util.Collections.addAll(collection_obj0, charSequence_array3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(charSequence_array3);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test49");
        java.util.Comparator<java.lang.AutoCloseable[]> comparator_autoCloseable_array0 = java.util.Collections.reverseOrder();
        org.junit.Assert.assertNotNull(comparator_autoCloseable_array0);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test50");
        java.util.List<java.util.TreeSet<java.lang.Object>> list_treeset_obj0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_treeset_obj0);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test51");
        java.util.List<java.lang.Iterable<java.lang.Object>> list_iterable_obj0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_iterable_obj0);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test52");
        java.util.Iterator<java.util.Spliterator<java.lang.Object>> iterator_spliterator_obj0 = java.util.Collections.emptyIterator();
        org.junit.Assert.assertNotNull(iterator_spliterator_obj0);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test53");
        java.util.Iterator<java.util.NavigableSet<java.lang.Object>> iterator_navigableset_obj0 = java.util.Collections.emptyIterator();
        org.junit.Assert.assertNotNull(iterator_navigableset_obj0);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test54");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.Comparator<java.lang.Object> comparator_obj1 = java.util.Collections.reverseOrder(comparator_obj0);
        java.util.TreeSet<java.lang.Object> treeset_obj2 = new java.util.TreeSet<java.lang.Object>(comparator_obj1);
        java.lang.Class<java.lang.Object> cls3 = null;
        try {
            java.util.SortedSet<java.lang.Object> sortedset_obj4 = java.util.Collections.checkedSortedSet((java.util.SortedSet<java.lang.Object>) treeset_obj2, cls3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(comparator_obj1);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test55");
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyNavigableMap();
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj1 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj2 = java.util.Collections.unmodifiableNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj1);
        java.lang.Class<java.util.ListIterator<java.lang.Comparable<java.lang.String>>> cls3 = null;
        java.lang.Class<java.util.NavigableSet<java.lang.Object>> cls4 = null;
        try {
            java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj5 = java.util.Collections.checkedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj1, cls3, cls4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj1);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj2);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test56");
        java.util.Collection<java.lang.Object> collection_obj0 = null;
        try {
            java.util.Enumeration<java.lang.Object> enumeration_obj1 = java.util.Collections.enumeration(collection_obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test57");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.SortedMap<java.util.RandomAccess, java.lang.String> sortedmap_randomAccess_str1 = java.util.Collections.emptySortedMap();
        java.util.Map<java.util.Comparator<java.lang.Object>, java.util.SortedMap<java.util.RandomAccess, java.lang.String>> map_comparator_obj_sortedmap_randomAccess_str2 = java.util.Collections.singletonMap(comparator_obj0, sortedmap_randomAccess_str1);
        java.util.TreeSet<java.lang.Object> treeset_obj3 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.Spliterator<java.lang.Object> spliterator_obj4 = treeset_obj3.spliterator();
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(sortedmap_randomAccess_str1);
        org.junit.Assert.assertNotNull(map_comparator_obj_sortedmap_randomAccess_str2);
        org.junit.Assert.assertNotNull(spliterator_obj4);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test58");
        java.util.NavigableMap<java.lang.String, java.util.Collection<java.lang.Object>> navigablemap_str_collection_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_str_collection_obj0);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test59");
        java.util.List<java.util.AbstractSet<java.lang.Object>> list_abstractset_obj0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_abstractset_obj0);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test60");
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyNavigableMap();
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj1 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.SortedSet<java.lang.Object>> navigablemap_listiterator_comparable_str_sortedset_obj2 = java.util.Collections.unmodifiableNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj1);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_sortedset_obj2);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test61");
        java.util.NavigableMap<java.util.SortedMap<java.util.RandomAccess, java.lang.String>, java.util.Enumeration<java.lang.Object>> navigablemap_sortedmap_randomAccess_str_enumeration_obj0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_sortedmap_randomAccess_str_enumeration_obj0);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test62");
        java.util.Map<java.lang.Object, java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>>> map_obj_navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyMap();
        org.junit.Assert.assertNotNull(map_obj_navigablemap_listiterator_comparable_str_navigableset_obj0);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test63");
        java.util.NavigableSet<java.io.Serializable> navigableset_serializable0 = java.util.Collections.emptyNavigableSet();
        org.junit.Assert.assertNotNull(navigableset_serializable0);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test64");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.TreeSet<java.lang.Object> treeset_obj2 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.Comparator<java.lang.Object> comparator_obj3 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj4 = new java.util.TreeSet<java.lang.Object>(comparator_obj3);
        boolean b6 = treeset_obj4.equals((java.lang.Object) (short) 0);
        java.util.Collection<java.lang.Object> collection_obj7 = java.util.Collections.unmodifiableCollection((java.util.Collection<java.lang.Object>) treeset_obj4);
        boolean b8 = treeset_obj2.equals((java.lang.Object) treeset_obj4);
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(comparator_obj3);
        org.junit.Assert.assertTrue(b6 == false);
        org.junit.Assert.assertNotNull(collection_obj7);
        org.junit.Assert.assertTrue(b8 == true);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test65");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.equals((java.lang.Object) (short) 0);
        java.lang.Object obj4 = null;
        java.lang.Object obj5 = treeset_obj1.lower(obj4);
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test66");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.equals((java.lang.Object) (short) 0);
        java.lang.Object obj4 = treeset_obj1.pollLast();
        java.lang.Class<java.lang.Object> cls5 = null;
        try {
            java.util.Set<java.lang.Object> set_obj6 = java.util.Collections.checkedSet((java.util.Set<java.lang.Object>) treeset_obj1, cls5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test67");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.add((java.lang.Object) (short) 1);
        java.util.NavigableSet<java.lang.Object> navigableset_obj4 = java.util.Collections.unmodifiableNavigableSet((java.util.NavigableSet<java.lang.Object>) treeset_obj1);
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == true);
        org.junit.Assert.assertNotNull(navigableset_obj4);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test68");
        java.util.Comparator<java.lang.Object> comparator_obj1 = null;
        java.util.List<java.util.Comparator<java.lang.Object>> list_comparator_obj2 = java.util.Collections.nCopies(0, comparator_obj1);
        org.junit.Assert.assertNotNull(list_comparator_obj2);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test69");
        java.util.SortedMap<java.lang.String, java.lang.Object> sortedmap_str_obj0 = java.util.Collections.emptySortedMap();
        org.junit.Assert.assertNotNull(sortedmap_str_obj0);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test70");
        java.util.Set<java.lang.CharSequence> set_charSequence1 = java.util.Collections.singleton((java.lang.CharSequence) "");
        org.junit.Assert.assertNotNull(set_charSequence1);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test71");
        java.util.Iterator<java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>>> iterator_navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyIterator();
        org.junit.Assert.assertNotNull(iterator_navigablemap_listiterator_comparable_str_navigableset_obj0);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test72");
        java.util.Enumeration<java.lang.Object> enumeration_obj0 = null;
        try {
            java.util.ArrayList<java.lang.Object> arraylist_obj1 = java.util.Collections.list(enumeration_obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test73");
        java.util.Iterator<java.util.Set<java.lang.Object>> iterator_set_obj0 = java.util.Collections.emptyIterator();
        org.junit.Assert.assertNotNull(iterator_set_obj0);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test74");
        java.util.List<java.util.Collection<java.lang.Object>> list_collection_obj0 = java.util.Collections.emptyList();
        org.junit.Assert.assertNotNull(list_collection_obj0);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test75");
        java.util.SortedMap<java.util.Iterator<java.lang.Comparable<java.lang.String>>, java.util.RandomAccess> sortedmap_iterator_comparable_str_randomAccess0 = java.util.Collections.emptySortedMap();
        org.junit.Assert.assertNotNull(sortedmap_iterator_comparable_str_randomAccess0);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test76");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        boolean b3 = treeset_obj1.equals((java.lang.Object) (short) 0);
        java.util.Set<java.lang.Object> set_obj4 = java.util.Collections.synchronizedSet((java.util.Set<java.lang.Object>) treeset_obj1);
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertTrue(b3 == false);
        org.junit.Assert.assertNotNull(set_obj4);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test77");
        java.util.NavigableMap<java.util.Enumeration<java.lang.Object>, java.util.Iterator<java.lang.Comparable<java.lang.String>>> navigablemap_enumeration_obj_iterator_comparable_str0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_enumeration_obj_iterator_comparable_str0);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test78");
        java.util.NavigableMap<java.util.AbstractCollection<java.lang.Object>, java.lang.CharSequence> navigablemap_abstractcollection_obj_charSequence0 = java.util.Collections.emptyNavigableMap();
        org.junit.Assert.assertNotNull(navigablemap_abstractcollection_obj_charSequence0);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test79");
        java.util.Comparator<java.lang.Object> comparator_obj0 = java.util.Collections.reverseOrder();
        java.util.TreeSet<java.lang.Object> treeset_obj1 = new java.util.TreeSet<java.lang.Object>(comparator_obj0);
        java.util.SortedSet<java.lang.Object> sortedset_obj2 = java.util.Collections.unmodifiableSortedSet((java.util.SortedSet<java.lang.Object>) treeset_obj1);
        treeset_obj1.clear();
        org.junit.Assert.assertNotNull(comparator_obj0);
        org.junit.Assert.assertNotNull(sortedset_obj2);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test80");
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj0 = java.util.Collections.emptyNavigableMap();
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj1 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj2 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj3 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj4 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj1);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj2);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj3);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj4);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test81");
        java.util.List list0 = java.util.Collections.EMPTY_LIST;
        java.util.Random random1 = null;
        java.util.Collections.shuffle((java.util.List<java.lang.Object>) list0, random1);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj3 = java.util.Collections.emptyNavigableMap();
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj4 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj3);
        java.util.NavigableMap<java.util.ListIterator<java.lang.Comparable<java.lang.String>>, java.util.NavigableSet<java.lang.Object>> navigablemap_listiterator_comparable_str_navigableset_obj5 = java.util.Collections.synchronizedNavigableMap(navigablemap_listiterator_comparable_str_navigableset_obj3);
        java.util.Collections.fill((java.util.List<java.lang.Object>) list0, (java.lang.Object) navigablemap_listiterator_comparable_str_navigableset_obj5);
        org.junit.Assert.assertNotNull(list0);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj3);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj4);
        org.junit.Assert.assertNotNull(navigablemap_listiterator_comparable_str_navigableset_obj5);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test82");
        java.util.SortedSet<java.lang.Comparable<java.lang.String>> sortedset_comparable_str0 = java.util.Collections.emptySortedSet();
        org.junit.Assert.assertNotNull(sortedset_comparable_str0);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test83");
        java.lang.Object obj4 = new java.lang.Object();
        java.lang.Object[] obj_array5 = new java.lang.Object[] { (byte) 1, (short) 100, (-1.0f), (short) 100, obj4 };
        java.util.ArrayList<java.lang.Object> arraylist_obj6 = new java.util.ArrayList<java.lang.Object>();
        boolean b7 = java.util.Collections.addAll((java.util.Collection<java.lang.Object>) arraylist_obj6, obj_array5);
        java.util.Collections.reverse((java.util.List<java.lang.Object>) arraylist_obj6);
        java.util.Collections.swap((java.util.List<java.lang.Object>) arraylist_obj6, (int) (short) 1, (int) (byte) 0);
        java.lang.String str12 = arraylist_obj6.toString();
        org.junit.Assert.assertNotNull(obj_array5);
        org.junit.Assert.assertTrue(b7 == true);
    }
}

